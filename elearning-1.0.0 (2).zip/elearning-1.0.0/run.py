from flask import Flask, render_template, request, redirect, flash, url_for,session
import sqlite3
from flask_sqlalchemy import SQLAlchemy
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
import os
from datetime import datetime  


app = Flask(__name__)
app.secret_key = '3f6b9cc0d5f1e4bba0c7af6c67c4d7fe'
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///users.db'
app.config['UPLOAD_FOLDER'] = 'uploads'
app.config['ALLOWED_EXTENSIONS'] = {'gif',  'jpeg', 'jpg', 'png'}
db = SQLAlchemy(app)
class Users(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    email = db.Column(db.String(120), unique=True, nullable=False)
    password = db.Column(db.String(200), nullable=False)
    role = db.Column(db.String(50), nullable=False)
    
    # Relationship to projects
    projects = db.relationship('Project', backref='user', lazy=True)
class Project(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(200), nullable=False)
    description = db.Column(db.Text, nullable=False)
    category = db.Column(db.String(100), nullable=False)
    file = db.Column(db.String(200), nullable=False)
    upload_date = db.Column(db.DateTime, default=datetime.utcnow)
    user_id = db.Column(db.Integer, db.ForeignKey('users.id'), nullable=False)

def init_db():
    db.create_all()

@app.route('/signup', methods=['GET', 'POST'])
def signup():
    if request.method == 'POST':
        name = request.form['name']
        email = request.form['email']
        password = request.form['password']
        confirm_password = request.form['confirmPassword']
        role = request.form['role']
        
        # Password validation
        if password != confirm_password:
            flash('Passwords do not match', 'danger')
            return redirect(url_for('signup'))
        try:
            conn = sqlite3.connect('Users.db')
            c = conn.cursor()
            c.execute("INSERT INTO Users (name, email, password, role) VALUES (?, ?, ?, ?)",
                      (name, email, password, role))
            conn.commit()
            conn.close()
            flash('You have successfully registered!', 'success')
            return redirect(url_for('login'))
            #return redirect(url_for('login'))
        except sqlite3.IntegrityError:
            flash('Email already exists', 'danger')

    return render_template('signup.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form['email']
        password = request.form['password']
        
        # Connect to the database
        conn = sqlite3.connect('users.db')
        c = conn.cursor()
        
        # Fetch user from database
        c.execute("SELECT * FROM Users WHERE email = ?", (email,))
        user = c.fetchone()  # This fetches one user
        
        if user:
            user_id, name, user_email, user_password, role = user
            
            # Directly compare the plain text password
            if user_password == password:
                
                # Store user info in session
                session['user_id'] = user_id
                session['email'] = email
                session['role'] = role

                # Redirect based on role
                if role == 'admin':
                    return redirect(url_for('admin_home'))
                elif role == 'user':
                    return redirect(url_for('index'))
            else:
                # Invalid password message
                return render_template('login.html', message='Incorrect password, please try again', message_type='danger')
        else:
            # Invalid email message
            return render_template('login.html', message='Email not found, please try again', message_type='danger')
        
        conn.close()

    return render_template('login.html')
@app.route('/')
def index():
    return render_template('index.html')

@app.route('/admin_home')
def admin_home():
    return render_template('admin_home.html')
@app.route('/about')
def about():
    return render_template('about.html')
@app.route('/logout')
def logout():
    session.clear()  # Clear the session when logging out
    return redirect(url_for('login'))
@app.route('/upload', methods=['GET', 'POST'])
def upload_project():
    if request.method == 'POST':
        title = request.form['title']
        description = request.form['description']
        category = request.form['category']
        file = request.files['file']
        
        # Check if the file is allowed
        if file and allowed_file(file.filename):
            filename = secure_filename(file.filename)
            file_path = os.path.join(app.config['UPLOAD_FOLDER'], filename)
            file.save(file_path)

            # Save project info to the database
            user_id = session.get('user_id')  # Get user_id from session
            if user_id is None:
                return redirect(url_for('login'))  # Redirect to login if user_id is not present

            new_project = Project(
                title=title,
                description=description,
                category=category,
                file=filename,
                user_id=user_id
            )
            db.session.add(new_project)
            db.session.commit()

            return redirect(url_for('index'))  # Redirect to home after upload

    return render_template('upload.html')

def allowed_file(filename):
    return '.' in filename and \
           filename.rsplit('.', 1)[1].lower() in app.config['ALLOWED_EXTENSIONS']

if __name__ == '__main__':
    with app.app_context():
        init_db()
    app.run()